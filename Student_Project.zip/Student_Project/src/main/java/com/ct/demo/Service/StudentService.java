package com.ct.demo.Service;

import java.util.List;

import com.ct.demo.Entity.Student;

public interface StudentService {

	List<Student> getAllStudents();
	
	Student sasveStudent(Student student);
	
	//int sumOfStudent(Student student,int English,int Maths,int Science); 
	
}

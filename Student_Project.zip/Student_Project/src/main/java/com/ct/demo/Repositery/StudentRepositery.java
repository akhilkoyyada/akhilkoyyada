package com.ct.demo.Repositery;


import org.springframework.data.jpa.repository.JpaRepository;

import com.ct.demo.Entity.Student;

public interface StudentRepositery extends JpaRepository<Student, Long>{

	

}

package com.ct.demo.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "semister1")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String stuName;
	private int English;
	private int Maths;
	private int Science;
	
	public Student(Long id, String stuName, int english, int maths, int science) {
		super();
		this.id = id;
		this.stuName = stuName;
		English = english;
		Maths = maths;
		Science = science;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public int getEnglish() {
		return English;
	}

	public void setEnglish(int english) {
		English = english;
	}

	public int getMaths() {
		return Maths;
	}

	public void setMaths(int maths) {
		Maths = maths;
	}

	public int getScience() {
		return Science;
	}

	public void setScience(int science) {
		Science = science;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", stuName=" + stuName + ", English=" + English + ", Maths=" + Maths + ", Science="
				+ Science + "]";
	}

	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
}

package com.ct.demo.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ct.demo.Entity.Student;
import com.ct.demo.Repositery.StudentRepositery;
import com.ct.demo.Service.StudentService;
@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	StudentRepositery studentRepositery;
	@Override
	public List<Student> getAllStudents() {
		
		return studentRepositery.findAll();
	}
	@Override
	public Student sasveStudent(Student student) {
		
		return studentRepositery.save(student);
	}
//	@Override
//	public int sumOfStudent(Student student, int English, int Maths, int Science) {
//		int sum = student.getEnglish() +student.getMaths()+student.getScience();
//		return sum;
//	}

}
